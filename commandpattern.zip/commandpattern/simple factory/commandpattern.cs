﻿namespace commandpattern
{
    public interface ICommand
    {
        void Execute();
    }

    class Light //Receiver
    {
        public void LightOn()
        {
            Console.WriteLine("Lights are on now");
        }
        public void LightOff()
        {
            Console.WriteLine("Lights are off now");

        }
    }

    class LightOnCommand : ICommand
    {
        private readonly Light _light;

        public LightOnCommand(Light light)
        {
            _light = light;
        }
        public void Execute()
        {
            _light.LightOn();
        }
    }

    class LightOffCommand : ICommand
    {
        private readonly Light _light;

        public LightOffCommand(Light light)
        {
            _light = light;
        }
        public void Execute()
        {
            _light.LightOff();
        }
    }

    public class Invoker
    {
        private readonly ICommand lightOn;
        private readonly ICommand lightOff;

        public Invoker(ICommand on, ICommand off)
        {
            this.lightOn = on;
            this.lightOff = off;
        }

        public void ClickOn()
        {
            lightOn.Execute();
        }

        public void ClickOff()
        {
            lightOff.Execute();
        }
    }
}
