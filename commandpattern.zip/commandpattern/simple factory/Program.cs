﻿// See https://aka.ms/new-console-template for more information



using commandpattern;

var light = new Light();
var lightCommandObj =new Invoker(new LightOnCommand(light), new LightOffCommand(light));
lightCommandObj.ClickOn();
Console.WriteLine("......");
lightCommandObj.ClickOff();




